package publicadministration;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TestQuotePeriodsColl {
    @Test
    public void testOrder(){
        QuotePeriodsColl quotePeriodColl = new QuotePeriodsColl();
        QuotePeriod quotePeriod1 = new QuotePeriod(new Date(),21);
        QuotePeriod quotePeriod2 = new QuotePeriod(new Date(2019,1,1),20);
        quotePeriodColl.addQuotePeriod(quotePeriod1);
        quotePeriodColl.addQuotePeriod(quotePeriod2);
        List<QuotePeriod> list=new ArrayList(quotePeriodColl.getPeriods().values());
        assert(list.get(0).equals(quotePeriod2));
        assert(list.get(1).equals(quotePeriod1));
    }
}
