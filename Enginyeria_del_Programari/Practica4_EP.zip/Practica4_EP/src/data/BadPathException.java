package data;

public class BadPathException extends Exception {
    public BadPathException(String message) {
        super(message);
    }
}
