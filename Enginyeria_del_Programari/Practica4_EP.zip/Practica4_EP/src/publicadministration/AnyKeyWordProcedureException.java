package publicadministration;

public class AnyKeyWordProcedureException extends Exception {
    public AnyKeyWordProcedureException(String message) {
        super(message);
    }
}
