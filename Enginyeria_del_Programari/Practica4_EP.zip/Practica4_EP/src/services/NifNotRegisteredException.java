package services;

public class NifNotRegisteredException extends Exception {
}
