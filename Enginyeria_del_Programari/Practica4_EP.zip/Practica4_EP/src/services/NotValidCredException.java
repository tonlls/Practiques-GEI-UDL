package services;

public class NotValidCredException extends Exception {
}
