package services;

public class AnyMobileRegisteredException extends Exception {
}
