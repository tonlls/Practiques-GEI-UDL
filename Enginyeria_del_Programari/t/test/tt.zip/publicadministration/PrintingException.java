package publicadministration;

public class PrintingException extends Exception {
    public PrintingException(String message) {
        super(message);
    }
}
