#include "Types.h"

#include <iostream>

void error(string message) 
{ 
	cerr << message << endl; exit(1); 
}

