public class Position {

    private final int x;
    private final int y;

    public Position(int x, int y) {
        throw new UnsupportedOperationException("TODO: Step1");
    }

    public int getX() {
        throw new UnsupportedOperationException("TODO: Step1");
    }

    public int getY() {
        throw new UnsupportedOperationException("TODO: Step1");
    }

    public boolean sameDiagonalAs(Position other) {
        throw new UnsupportedOperationException("TODO: Step1");
    }

    public static int distance(Position pos1, Position pos2) {
        throw new UnsupportedOperationException("TODO: Step1");
    }

    public static Position middle(Position pos1, Position pos2) {
        throw new UnsupportedOperationException("TODO: Step1");
    }

    // Needed for testing and debugging

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Position position = (Position) o;
        return x == position.x && y == position.y;
    }

    @Override
    public String toString() {
        return "Position{" +
                "x=" + x +
                ", y=" + y +
                '}';
    }
}

