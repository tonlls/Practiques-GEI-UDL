public class Direction {

    public static final Direction NW = null;
    public static final Direction NE = null;
    public static final Direction SW = null;
    public static final Direction SE = null;

    private final int dx;
    private final int dy;

    private Direction(int dx, int dy) {
        throw new UnsupportedOperationException("TODO: Step2");
    }

    public Position apply(Position from) {
        throw new UnsupportedOperationException("TODO: Step2");
    }
}
