public class Cell {

    private static final char C_FORBIDDEN = '·';
    private static final char C_EMPTY = ' ';
    private static final char C_WHITE = 'w';
    private static final char C_BLACK = 'b';

    public static final Cell FORBIDDEN = null;
    public static final Cell EMPTY = null;
    public static final Cell WHITE = null;
    public static final Cell BLACK = null;

    private final char status;

    private Cell(char status) {
        throw new UnsupportedOperationException("TODO: Step3");
    }

    public static Cell fromChar(char status) {
        throw new UnsupportedOperationException("TODO: Step3");
    }

    public boolean isForbidden() {
        throw new UnsupportedOperationException("TODO: Step3");
    }

    public boolean isEmpty() {
        throw new UnsupportedOperationException("TODO: Step3");
    }

    public boolean isWhite() {
        throw new UnsupportedOperationException("TODO: Step3");
    }

    public boolean isBlack() {
        throw new UnsupportedOperationException("TODO: Step3");
    }

    @Override
    public String toString() {
        return String.valueOf(status);
    }
}