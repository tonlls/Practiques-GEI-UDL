public class Game {

    private static final Direction[] WHITE_DIRECTIONS = {Direction.NW, Direction.NE};
    private static final Direction[] BLACK_DIRECTIONS = {Direction.SW, Direction.SE};

    private final Board board;
    private Player currentPlayer;
    private boolean hasWon;

    public Game(Board board) {
        throw new UnsupportedOperationException("TODO: Step5");
    }

    public Player getCurrentPlayer() {
        throw new UnsupportedOperationException("TODO: Step5");
    }

    public boolean hasWon() {
        throw new UnsupportedOperationException("TODO: Step5");
    }

    public boolean isValidFrom(Position position) {
        throw new UnsupportedOperationException("TODO: Step5");
    }

    // Assumes validFrom is a valid starting position
    public boolean isValidTo(Position validFrom, Position to) {
        throw new UnsupportedOperationException("TODO: Step5");
    }

    // Assumes both positions are valid
    public Move move(Position validFrom, Position validTo) {
        throw new UnsupportedOperationException("TODO: Step5");
    }

    // Only for testing

    public void setPlayerForTest(Player player) {
        this.currentPlayer = player;
    }
}
