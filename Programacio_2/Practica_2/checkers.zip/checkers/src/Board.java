import java.util.StringTokenizer;

// Only a rectangle of cells. Does not know the game rules.

public class Board {

    private final int width;
    private final int height;
    private final Cell[][] cells;
    private int numBlacks;
    private int numWhites;

    public Board(int width, int height, String board) {
        throw new UnsupportedOperationException("TODO: Step4");
    }

    public int getWidth() {
        throw new UnsupportedOperationException("TODO: Step4");
    }

    public int getHeight() {
        throw new UnsupportedOperationException("TODO: Step4");
    }

    public int getNumBlacks() {
        throw new UnsupportedOperationException("TODO: Step4");
    }

    public int getNumWhites() {
        throw new UnsupportedOperationException("TODO: Step4");
    }

    public boolean isForbidden(Position pos) {
        throw new UnsupportedOperationException("TODO: Step4");
    }

    public boolean isBlack(Position pos) {
        throw new UnsupportedOperationException("TODO: Step4");
    }

    public boolean isWhite(Position pos) {
        throw new UnsupportedOperationException("TODO: Step4");
    }

    public boolean isEmpty(Position pos) {
        throw new UnsupportedOperationException("TODO: Step4");
    }

    public void setBlack(Position pos) {
        throw new UnsupportedOperationException("TODO: Step4");
    }

    public void setWhite(Position pos) {
        throw new UnsupportedOperationException("TODO: Step4");
    }

    public void setEmpty(Position pos) {
        throw new UnsupportedOperationException("TODO: Step4");
    }

    // For testing and debugging

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                sb.append(cells[y][x].toString());
            }
            if (y != height - 1) {
                sb.append("\n");
            }
        }
        return sb.toString();
    }
}
