
package domain;

import utils.PackUtils;

public class Book {
    
    public static final int TITLE_LIMIT = 20;
    public static final int SIZE = -1; // step 1
    
    private final long id;
    private final String title;
    private long idMember;

    public Book(long id, String title) {
        throw new UnsupportedOperationException("step 1");
    }
        
    private Book(long id, String title, long idSoci) {
        throw new UnsupportedOperationException("step 1");
    }

    public long getId() {
        throw new UnsupportedOperationException("step 1");
    }

    public String getTitle() {
        throw new UnsupportedOperationException("step 1");
    }

    public long getIdMember() {
        throw new UnsupportedOperationException("step 1");
    }

    public void setIdMember(long idMember) {
        throw new UnsupportedOperationException("step 1");
    }
    
    public static Book fromBytes(byte[] record) {
        throw new UnsupportedOperationException("step 1");
    }
    
    public byte[] toBytes() {
        throw new UnsupportedOperationException("step 1");
    }
}
