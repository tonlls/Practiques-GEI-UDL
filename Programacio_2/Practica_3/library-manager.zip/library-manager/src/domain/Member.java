
package domain;

import utils.PackUtils;

public class Member {
    
    private static final int MAX_BOOKS = 3;
    
    public static final int NAME_LIMIT = 20;
    public static final int ADDRESS_LIMIT = 30;
    public static final int SIZE = -1; // step 2
    
    private final long id;
    private final String name;
    private final String address;
    private final long[] idBooks;

    public Member(long id, String name, String address) {
        throw new UnsupportedOperationException("step 2");
    }
    
    private Member(long id, String name, String address, long[] idBooks) {
        throw new UnsupportedOperationException("step 2");
    }

    public long getId() {
        throw new UnsupportedOperationException("step 2");
    }

    public String getName() {
        throw new UnsupportedOperationException("step 2");
    }

    public String getAddress() {
        throw new UnsupportedOperationException("step 2");
    }

    public int countBooks() {
        throw new UnsupportedOperationException("step 2");
    }

    public boolean canBorrow() {
        throw new UnsupportedOperationException("step 2");
    }
        
    public void addBook(long idBook) {
        throw new UnsupportedOperationException("step 2");
    }

    public void removeBook(long idBook) {
        throw new UnsupportedOperationException("step 2");
    }

    public boolean containsBook(long idBook) {
        throw new UnsupportedOperationException("step 2");
    }

    public static Member fromBytes(byte[] record) {
        throw new UnsupportedOperationException("step 2");
    }

    public byte[] toBytes() {
        throw new UnsupportedOperationException("step 2");
    }
}
