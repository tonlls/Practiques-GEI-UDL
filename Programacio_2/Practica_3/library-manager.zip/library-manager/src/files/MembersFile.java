
package files;

import domain.Member;
import java.io.IOException;
import java.io.RandomAccessFile;

public class MembersFile {
    
    private final RandomAccessFile raf;
    
    public MembersFile(String fname) throws IOException {
        throw new UnsupportedOperationException("step 4");
    }
    
    public void clear() throws IOException {
        throw new UnsupportedOperationException("step 4");
    }
    
    public Member read(long id) throws IOException {
        throw new UnsupportedOperationException("step 4");
    }
    
    public void write(Member member) throws IOException {
        throw new UnsupportedOperationException("step 4");
    }
    
    public long length() throws IOException {
        throw new UnsupportedOperationException("step 4");
    }
    
    public void close() throws IOException {
        throw new UnsupportedOperationException("step 4");
    }   
}