
package files;

import domain.Book;
import java.io.IOException;
import java.io.RandomAccessFile;

public class BooksFile {
    
    private final RandomAccessFile raf;
    
    public BooksFile(String fname) throws IOException {
        throw new UnsupportedOperationException("step 3");
    }
    
    public void clear() throws IOException {
        throw new UnsupportedOperationException("step 3");
    }
    
    public Book read(long id) throws IOException {
        throw new UnsupportedOperationException("step 3");
    }
    
    public void write(Book book) throws IOException {
        throw new UnsupportedOperationException("step 3");
    }
    
    public long length() throws IOException {
        throw new UnsupportedOperationException("step 3");
    }
    
    public void close() throws IOException {
        throw new UnsupportedOperationException("step 3");
    }
}