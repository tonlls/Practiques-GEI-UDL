
package librarymanager;

import acm.program.CommandLineProgram;
import domain.Book;
import domain.Member;
import files.BooksFile;
import files.LogFile;
import files.MembersFile;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

public class LibraryManager extends CommandLineProgram {

    private static final String BOOKS = "llibres.dat";
    private static final String MEMBERS = "socis.dat";
    private static final String LOG = "manager.log";
    private static final String MOVEMENTS = "movements.csv";

    private BufferedReader movements;

    private BooksFile booksFile;
    private MembersFile membersFile;
    private LogFile logFile;

    private int movementNumber;

    // Entry points

    public static void main(String[] args) {
        new LibraryManager().start(args);
    }

    public void run() {
        try {
            openFiles();
            processMovements();
            closeFiles();
        } catch (IOException ex) {
            println("ERROR (something about the files)");
        }
    }

    // Opening and closing

    private void openFiles() throws IOException {
        throw new UnsupportedOperationException("step 5");
    }

    private void closeFiles() throws IOException {
        throw new UnsupportedOperationException("step 5");
    }

    // Movements processing

    private void processMovements() throws IOException {
        throw new UnsupportedOperationException("step 5");
    }
}