
package sorting;

/**
 * @author jmgimeno
 */
public class InsertionSortTest extends AbstractSortTest {

    @Override
    protected void doSort() {
        sorting.insertionSort();
    }
}
