
package sorting;

/**
 *
 * @author jmgimeno
 */
public class QuickSortSortTest extends AbstractSortTest {

    @Override
    protected void doSort() {
        sorting.quickSort();
    }
}
