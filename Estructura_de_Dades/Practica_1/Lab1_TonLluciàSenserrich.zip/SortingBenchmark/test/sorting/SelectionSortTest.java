
package sorting;

/**
 *
 * @author jmgimeno
 */
public class SelectionSortTest extends AbstractSortTest {

    @Override
    protected void doSort() {
        sorting.selectionSort();
    }
}
