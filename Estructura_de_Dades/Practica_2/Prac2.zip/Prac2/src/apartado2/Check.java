package apartado2;

public interface Check<E> {
    boolean test(E e);
}
